function send(msg){ return new Promise(r=>chrome.runtime.sendMessage(msg, r)); }

async function refresh(){
  const state = await send({type:"get_state"});
  const opts = state.opts || {};
  document.getElementById("count").textContent = (state.rows||[]).length;
  document.getElementById("filename").value = opts.overwriteFilename || "sahibinden_toplu.xlsx";
  const cb = document.getElementById("enabled");
  cb.checked = !!opts.enabled;
  document.getElementById("enabledText").textContent = cb.checked ? "Açık" : "Kapalı";
  document.getElementById("note").textContent = "";
}

document.getElementById("enabled").addEventListener("change", async (e)=>{
  const enabled = e.target.checked;
  const resp = await send({ type:"set_opts", opts:{ enabled } });
  document.getElementById("enabledText").textContent = enabled ? "Açık" : "Kapalı";
});

document.getElementById("exportNow").addEventListener("click", async ()=>{
  const resp = await send({ type: "export_now" });
  const note = document.getElementById("note");
  if (!resp?.ok) note.textContent = "İndirme başarısız: " + (resp?.error || "bilinmiyor");
  else if (resp?.mode === "csv" && resp?.note) note.textContent = resp.note + " (dosya CSV olarak indi)";
  else if (resp?.mode === "xlsx") note.textContent = "Excel dosyası indirildi.";
  else note.textContent = "";
});

document.getElementById("clear").addEventListener("click", async ()=>{
  if(!confirm("Tüm kayıtları temizlemek istiyor musun?")) return;
  await send({ type:"clear_rows" });
  refresh();
});

document.getElementById("filename").addEventListener("change", async (e)=>{
  const v=(e.target.value||"").trim() || "sahibinden_toplu.xlsx";
  await send({ type:"set_opts", opts:{ overwriteFilename: v } });
  refresh();
});

refresh();
