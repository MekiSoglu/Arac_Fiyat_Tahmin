// v3.5 — Aç/Kapa: kapalıyken çalışmaz. Fiyat + Link eklendi. Boş span => "Orjinal".
(function(){
  let active = false;
  let sent = false;
  let mo = null;

  const norm = s => (s||"").replace(/\u00A0/g," ").replace(/\s+/g," ").trim();
  const q = s => document.querySelector(s);
  const qa = s => Array.from(document.querySelectorAll(s));

  const PART_NAME_MAP = {
    "front-bumper":"Ön Tampon","front-hood":"Motor Kaputu","roof":"Tavan",
    "front-right-mudguard":"Sağ Ön Çamurluk","front-right-door":"Sağ Ön Kapı",
    "rear-right-door":"Sağ Arka Kapı","rear-right-mudguard":"Sağ Arka Çamurluk",
    "front-left-mudguard":"Sol Ön Çamurluk","front-left-door":"Sol Ön Kapı",
    "rear-left-door":"Sol Arka Kapı","rear-left-mudguard":"Sol Arka Çamurluk",
    "rear-hood":"Bagaj Kapağı","rear-bumper":"Arka Tampon"
  };

  
  
  function statusFromSpan(span){
    const raw = ((span && span.textContent) || "").replace(/\u00A0/g," ").trim().toUpperCase();
    if (!raw) return "Orjinal";
    if (raw === "LB") return "Lokal Boyalı";
    if (raw === "B")  return "Boyalı";
    if (raw === "D")  return "Değişen";
    return "Orjinal";
  }

  function scrapeKV() {
    const ul = q("ul.classifiedInfoList");
    if (!ul) return {};
    const rec = {};
    for (const li of qa("ul.classifiedInfoList > li")) {
      const kEl = li.querySelector("strong");
      const vEl = li.querySelector("strong ~ span") || li.querySelector("span");
      const key = norm(kEl?.textContent || "").replace(/\s*:\s*$/, "");
      const val = norm(vEl?.textContent || "");
      if (key) rec[key] = val;
    }
    return rec;
  }

  function scrapeParts() {
    const out = {};
    const divs = qa("div.car-parts > div");
    for (const d of divs) {
      const classes = (d.className || "").split(/\s+/).filter(Boolean);
      let partKey = null;
      for (const c of classes) if (PART_NAME_MAP[c]) { partKey = c; break; }
      if (!partKey) continue;
      const human = PART_NAME_MAP[partKey];
      const span = d.querySelector("span");
      const status = statusFromSpan(span);
      out[human] = status;
    }
    return out;
  }

  function scrapePrice() {
    // Farklı varyasyonlar için birkaç yedek seçici
    const el = q(".classified-price-wrapper")
           || q("#classifiedPrice")
           || q("[itemprop='price']")
           || q(".classifiedInfo h3 ~ .classified-price-wrapper");
    if (!el) return "";
    let txt = norm(el.textContent || "");
    // Bazı durumlarda metnin içine fazlalık/boşluk girebiliyor — temizle
    txt = txt.replace(/\s+/g, " ").trim();
    return txt;
  }

  function scrapeLink() {
    // İlan linki: bulunduğumuz sayfa
    try {
      return window.location.href.split("#")[0];
    } catch(e){ return window.location.href; }
  }

  function maybeSend() {
    if (!active || sent) return;
    const kv = scrapeKV();
    if (Object.keys(kv).length < 2) return;
    const parts = scrapeParts();
    const price = scrapePrice();
    const link  = scrapeLink();

    const data = { ...kv, ...parts };
    if (price) data["Fiyat"] = price;
    data["Link"] = link;

    sent = true;
    chrome.runtime.sendMessage({ type: "record", data }, ()=>{});
  }

  function start() {
    if (active) return;
    active = true;
    sent = false;
    if (mo) { try{ mo.disconnect(); }catch(e){} }
    mo = new MutationObserver(maybeSend);
    mo.observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener("load", ()=>setTimeout(maybeSend, 1000), { once: true });
    setTimeout(maybeSend, 4000);
  }

  function stop() {
    active = false;
    if (mo) { try{ mo.disconnect(); }catch(e){} mo = null; }
  }

  // Başlangıçta storage'dan enabled'ı oku
  chrome.storage.local.get(["opts"], (obj)=>{
    const enabled = !!(obj && obj.opts && obj.opts.enabled);
    if (enabled) start(); else stop();
  });

  // Aç/Kapa değişimini izle
  chrome.storage.onChanged.addListener((changes, area)=>{
    if (area !== "local") return;
    if (!changes.opts) return;
    const newOpts = changes.opts.newValue || {};
    const enabled = !!newOpts.enabled;
    if (enabled) start(); else stop();
  });
})();