// === BACKGROUND v3.4b — Aç/Kapa + sabit parça kolonları ===
const STATE_KEY = "rows";
const OPTS_KEY  = "opts";

// Parça kolonlarının sabit sırası (bitişik)
const PART_ORDER = [
  "Ön Tampon","Motor Kaputu","Tavan",
  "Sağ Ön Çamurluk","Sağ Ön Kapı","Sağ Arka Kapı","Sağ Arka Çamurluk",
  "Sol Ön Çamurluk","Sol Ön Kapı","Sol Arka Kapı","Sol Arka Çamurluk",
  "Bagaj Kapağı","Arka Tampon"
];

const defaultOpts = {
  enabled: false,                 // varsayılan: kapalı
  autoExport: false,
  overwriteFilename: "sahibinden_toplu.xlsx",
  delimiter: ";"
};

let hasXLSX = false, XLSX = null;
try { importScripts('xlsx.full.min.js'); XLSX = self.XLSX || null; hasXLSX = !!(XLSX && XLSX.utils && XLSX.write); }
catch(e){ hasXLSX = false; }

async function getState() {
  const obj = await chrome.storage.local.get([STATE_KEY, OPTS_KEY]);
  return { rows: Array.isArray(obj[STATE_KEY]) ? obj[STATE_KEY] : [], opts: { ...defaultOpts, ...(obj[OPTS_KEY] || {}) } };
}
async function setRows(rows) { await chrome.storage.local.set({ [STATE_KEY]: rows }); }
async function setOpts(opts) { await chrome.storage.local.set({ [OPTS_KEY]: opts }); }

function buildHeaders(rows) {
  const set = new Set();
  for (const r of rows) Object.keys(r||{}).forEach(k => set.add(k));

  // İlan temel alanları önce (varsa)
  const preferred = ["İlan No","İlan Tarihi","Marka","Seri","Model","Yıl","KM"];
  const head = [];
  for (const p of preferred) if (set.has(p)) { head.push(p); set.delete(p); }

  // Parça kolonları sabit sırada ve bitişik
  for (const part of PART_ORDER) { head.push(part); set.delete(part); }

  // Kalan diğer alanlar (Renk, Vites, vs) alfabetik
  const rest = Array.from(set).sort((a,b)=>a.localeCompare(b,'tr'));
  return head.concat(rest);
}

function csvEscape(v, delim) {
  if (v==null) return "";
  const s = String(v);
  const needs = s.includes('"') || s.includes("\n") || s.includes("\r") || s.includes(delim);
  const body = s.replace(/"/g,'""');
  return needs ? `"${body}"` : body;
}

function csvFromRows(rows, delim) {
  const headers = buildHeaders(rows);
  const lines = [headers.map(h=>csvEscape(h,delim)).join(delim)];
  for (const r of rows) lines.push(headers.map(h=>csvEscape(r[h]??"",delim)).join(delim));
  return "\uFEFF" + lines.join("\r\n");
}

function aoaFromRows(rows) {
  const headers = buildHeaders(rows);
  const aoa = [headers];
  for (const r of rows) aoa.push(headers.map(h => r[h] ?? ""));
  return aoa;
}

async function exportAll() {
  const { rows, opts } = await getState();
  if (!rows.length) throw new Error("Henüz kayıt yok");

  if (hasXLSX) {
    try {
      const aoa = aoaFromRows(rows);
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(aoa);
      XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
      const ab = XLSX.write(wb, { bookType: "xlsx", type: "array" });
      const blob = new Blob([ab], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      await chrome.downloads.download({ url, filename: (opts.overwriteFilename || "sahibinden_toplu.xlsx"), saveAs: true });
      setTimeout(()=>URL.revokeObjectURL(url), 60_000);
      return { mode: "xlsx" };
    } catch (e) {
      const csv = csvFromRows(rows, opts.delimiter || ";");
      const dataUrl = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
      const fname = (opts.overwriteFilename || "sahibinden_toplu.xlsx").replace(/\.xlsx$/i, ".csv");
      await chrome.downloads.download({ url: dataUrl, filename: fname, saveAs: true });
      return { mode: "csv", note: "XLSX başarısız: " + e.message };
    }
  } else {
    const csv = csvFromRows(rows, opts.delimiter || ";");
    const dataUrl = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    const fname = (opts.overwriteFilename || "sahibinden_toplu.xlsx").replace(/\.xlsx$/i, ".csv");
    await chrome.downloads.download({ url: dataUrl, filename: fname, saveAs: true });
    return { mode: "csv", note: "XLSX kütüphanesi yok; CSV indirildi." };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "record") {
    (async () => {
      const { rows, opts } = await getState();
      if (!opts.enabled) { sendResponse({ ok: false, disabled: true }); return; } // kapalıysa kayıt yapma
      rows.push(msg.data);
      await setRows(rows);
      if (opts.autoExport) { try { await exportAll(); } catch(e){} }
      sendResponse({ ok: true, total: rows.length });
    })();
    return true;
  }
  else if (msg?.type === "export_now") {
    (async () => {
      try { const r = await exportAll(); sendResponse({ ok: true, ...r }); }
      catch(e){ sendResponse({ ok:false, error: e.message }); }
    })();
    return true;
  }
  else if (msg?.type === "get_state") {
    (async () => sendResponse(await getState()))();
    return true;
  }
  else if (msg?.type === "clear_rows") {
    (async () => { await setRows([]); sendResponse({ ok: true }); })();
    return true;
  }
  else if (msg?.type === "set_opts") {
    (async () => {
      const state = await getState();
      const next = { ...state.opts, ...(msg.opts||{}) };
      await setOpts(next);
      sendResponse({ ok: true, opts: next });
    })();
    return true;
  }
});
