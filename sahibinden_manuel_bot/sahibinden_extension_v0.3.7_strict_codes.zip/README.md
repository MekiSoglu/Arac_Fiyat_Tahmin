# Sahibinden İlan Kaydedici — v3.4b (Aç/Kapa)
- Aç/Kapa butonu: Kapalıyken hiç kayıt alınmaz. Açınca yeni sekmelerde toplanır.
- `ul.classifiedInfoList > li` → kolon/değer
- `div.car-parts > div` → parça durumu (boşsa **Orjinal**)
- Parça kolonları sabit sırada ve bitişik
- Dışa aktarım: **XLSX** (xlsx.full.min.js varsa), yoksa **CSV (;)**

Kurulum: `chrome://extensions` → Developer mode → Load unpacked → bu klasör.
Excel istiyorsan, SheetJS dosyasını (xlsx.full.min.js) bu klasöre koy ve eklentiyi Reload et.
